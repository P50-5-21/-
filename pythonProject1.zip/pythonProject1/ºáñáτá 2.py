
print("Это прогрмма для подсчета")
number = int(input("Введите целое число a: ")) # Вводим переменную "number" для работы с числами.
if number > 0:        # Вводим условие if, для сравнение a с 0.
    print("Число number является положительным")
    number = number + 1
    print(number)     # Результат переменной "number".
elif number < 0:      # Вводим условие elif, для того чтобы вводимое число было меньше 0.
    print("Число number является отрицательным")
    number = number - 2
    print(number)     # Результат переменной "number".
elif number == 0:     # Вводим условие elif, для того чтобы прировнять вводимое число к 0.
    print("Число number является нулевым")
    number = number + 10
    print(number)     # Результат переменной "number".
